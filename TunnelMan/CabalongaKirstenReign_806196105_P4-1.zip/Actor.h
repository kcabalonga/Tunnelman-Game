#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

// base class for game objects
class Actor : public GraphObject {
public:
    Actor(StudentWorld* world, int imageID, int startX, int startY, Direction dir, double size, unsigned int depth);
    virtual ~Actor();
    
    StudentWorld* getWorld();
    bool isAlive();
    void die();
    void moveTo(int x, int y);
    virtual void doSomething() = 0;

private:
    StudentWorld* m_world;
    bool m_isAlive;
};

class Earth : public Actor {
public:
    Earth(StudentWorld* world, int startX, int startY);
    virtual ~Earth();
    
    virtual void doSomething();
};


class Tunnelman : public Actor {
public:
    Tunnelman(StudentWorld* world);
    ~Tunnelman();
    
    int getHp();
    void subtractHp(int pts);
    virtual void doSomething();
    void moveInDir(Direction dir);

private:
    int m_hp;
};

#endif // ACTOR_H_
