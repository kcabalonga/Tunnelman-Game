#include "Actor.h"
#include "StudentWorld.h"
using namespace std;

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

// Actor Implementation
Actor::Actor(StudentWorld* world, int imageID, int startX, int startY, Direction dir, double size, unsigned int depth)
: GraphObject(imageID, startX, startY, dir, size, depth), m_world(world), m_isAlive(true)
{
    setVisible(true);
}

Actor::~Actor()
{
    setVisible(false);
}

StudentWorld* Actor::getWorld()
{
    return m_world;
}

bool Actor::isAlive()
{
    return m_isAlive;
}

void Actor::die()
{
    m_isAlive = false;
}

void Actor::moveTo(int x, int y) // can only move within bounds
{
    if (x < 0)
        x = 0;
    if (x > 60)
        x = 60;
    if (y < 0)
        y = 0;
    if (y > 60)
        y = 60;
    
    GraphObject::moveTo(x, y);
}

// Earth Implementation
Earth::Earth(StudentWorld* world, int startX, int startY)
: Actor(world, TID_EARTH, startX, startY, right, 0.25, 3) {}

Earth::~Earth() {}

void Earth::doSomething() {}

// Tunnelman Implementation
Tunnelman::Tunnelman(StudentWorld* world)
: Actor(world, TID_PLAYER, 30, 60, right, 1.0, 0), m_hp(10) {}

Tunnelman::~Tunnelman() {}

int Tunnelman::getHp()
{
    return m_hp;
}

void Tunnelman::subtractHp(int pts)
{
    m_hp -= pts;
}

void Tunnelman::doSomething()
{
    if (!isAlive()) // if dead, can't move
        return;
    
    if (getWorld()->canDig(getX(), getY())) {  // if digging, play dig sound
        getWorld()->playSound(SOUND_DIG);
    }
    
    int key;
    if (getWorld()->getKey(key)) { // directional keys
        switch (key) {
            case KEY_PRESS_ESCAPE:
                die();
                break;
            case KEY_PRESS_UP:
                moveInDir(up);
                break;
            case KEY_PRESS_DOWN:
                moveInDir(down);
                break;
            case KEY_PRESS_LEFT:
                moveInDir(left);
                break;
            case KEY_PRESS_RIGHT:
                moveInDir(right);
                break;
            default:
                break;
        }
    }
}

void Tunnelman::moveInDir(Direction dir)
{
    switch (dir) {
        case up: // change direction if different key, move in direction if same key
            if (getDirection() == up)
                moveTo(getX(), getY() + 1);
            else
                setDirection(up);
            break;
        case down:
            if (getDirection() == down)
                moveTo(getX(), getY() - 1);
            else
                setDirection(down);
            break;
        case left:
            if (getDirection() == left)
                moveTo(getX() - 1, getY());
            else
                setDirection(left);
            break;
        case right:
            if (getDirection() == right)
                moveTo(getX() + 1, getY());
            else
                setDirection(right);
            break;
        default:
            break;
    }
}
