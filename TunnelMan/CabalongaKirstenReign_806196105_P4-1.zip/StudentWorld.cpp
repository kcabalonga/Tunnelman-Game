#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"

#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
    return new StudentWorld(assetDir);
}
// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetDir)
    : GameWorld(assetDir) {}

StudentWorld::~StudentWorld() // same as clean up
{
    for (int x = 0; x < 64; x++) {
        for (int y = 0; y < 60; y++) {
            delete m_earth[x][y];
        }
    }
    
    delete m_player;
}

int StudentWorld::init()
{
    // initialize data structures to keep track of virtual world
    // construct new oil field that meets requirements
    // allocate and insert valid TunnelMan object at proper location
    
    for (int x = 0; x < 64; x++) { // new oil field
        for (int y = 0; y < 60; y++) {
            if (x < 30 || x > 33 || y < 4) { // leave middle empty
                m_earth[x][y] = new Earth(this, x, y);
            }
        }
    }
    
    m_player = new Tunnelman(this); // new tunnelman
    
    return GWSTATUS_CONTINUE_GAME;
}


int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    
    m_player->doSomething();
    
    
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp() // delete earth, delete player
{
    for (int x = 0; x < 64; x++) {
        for (int y = 0; y < 60; y++) {
            delete m_earth[x][y];
        }
    }
    
    delete m_player;

}

bool StudentWorld::canDig(int x, int y)
{
    bool isClear = false;
    
    for (int i = x; i < x + 4; i++) {
        for (int j = y; j < y + 4; j++) {
            if (m_earth[i][j] != nullptr) { // if earth in the way, delete and dig
                delete m_earth[i][j];
                m_earth[i][j] = nullptr;
                isClear = true;
            }
        }
    }
    
    return isClear;
}


